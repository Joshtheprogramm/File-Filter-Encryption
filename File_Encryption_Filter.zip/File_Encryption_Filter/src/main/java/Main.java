import java.io.*;
public class Main 
{
    //main class has Exceptions called in the header.
    public static void main (String[]args)
                            throws IOException, ClassNotFoundException
    {   
        //char arrays made. 1st array is used to create the 1st file, and the second array will write to the new altered file.
        char letter[] = {'H','E','L','L','O','W','O','R','L','D'};
        char letter2[]= new char[letter.length];
        //Creates new file that can be read and written to. 
        //Statement announces process to user
        RandomAccessFile thisfile = new RandomAccessFile("Alpha.dat","rw");
        System.out.println("Writing data to file");
        //Writes bytes to file
        for (int i=0;i<letter.length;i++)
        {System.out.println(letter[i]);}
        System.out.println("\nDone\n");
        //Variables called
        int size = 3;
        long byteNum;
        char ch;
        //2nd file is created
        FileOutputStream file = new FileOutputStream("Alpha2.dat");
        ObjectOutputStream outStream = new ObjectOutputStream(file);
        //Alterations are made to original file and then saved to 2nd file
        //Code changes memory address by 4 bytes as it steps through the 1st array.
        for (int t=0;t<letter.length;t++){
        byteNum = size*4;
        thisfile.seek(byteNum);
        ch = thisfile.readChar();
        System.out.println(ch);
        outStream.writeObject(letter2[t]);
        size++;
        }
        //file closes
        file.close();
        //Calls class to display 2nd file
        new_Message(letter.length);
    }
    //Public class is made to read from file. Uses array in main class for count length. Exceptions are called in the header.
    public static void new_Message(int x)
            throws IOException, ClassNotFoundException
    {
        //Read to file 
        FileInputStream inStream = new FileInputStream("Alpha2.dat");
        ObjectInputStream inputFile = new ObjectInputStream(inStream);
        //Array that reads from the original file, by storing bytes and then displaying them.
        char letter3[]=new char[50];
        for (int a=0;a<x;a++){letter3[a]= (char) inputFile.readObject();}
        //File close
        inputFile.close();
    }
}
